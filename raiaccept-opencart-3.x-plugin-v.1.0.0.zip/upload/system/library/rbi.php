<?php
/**
 * Copyright (c) 2023 Raiffeisenbank International
*/

class Rbi {
	const CLIENT_ID = 'kr2gs4117arvbnaperqff5dml';

	const AUTH_URL = 'https://authenticate.raiaccept.com';
	const TRANSACTION_API = 'https://trapi.raiaccept.com';

	const ORDERS_URL = self::TRANSACTION_API . '/orders';
	const REFUNDS_URL = self::ORDERS_URL . '/%s/transactions/%s/refund';
	const TRANSACTION_STATUS_URL = self::ORDERS_URL . '/%s/transactions/%s';
	const ORDER_TRANSACTIONS_STATUSES_URL = self::ORDERS_URL . '/%s/transactions';

	public $prefix = 'payment_rbi_';

	public $load;
	public $session;
	public $config;

	public function __construct($registry) {
		$this->load = $registry->get('load');
		$this->session = $registry->get('session');
		$this->config = $registry->get('config');
	}

	public function get($setting) {
		if (strpos($setting, $this->prefix) !== 0) {
			$setting = $this->prefix . $setting;
		}

		return $this->config->get($setting);
	}

	public function getRefundUrl($rbi_order) {
		return sprintf(
			self::REFUNDS_URL,
			$rbi_order['orderIdentification'],
			$rbi_order['response']['transaction']['transactionId']
		);
	}

	public function getStatusUrl($rbi_order, $transactionId = '') {
		return sprintf(
			self::TRANSACTION_STATUS_URL,
			$rbi_order['orderIdentification'],
			$transactionId
		);
	}

	public function getOrderStatusesUrl($rbi_order) {
		return sprintf(
			self::ORDER_TRANSACTIONS_STATUSES_URL,
			$rbi_order['orderIdentification']
		);
	}

	public function getUsername() {
		return $this->get($this->get('mode') . '_username');
	}

	public function getPassword() {
		return $this->get($this->get('mode') . '_password');
	}

	public function retrieveToken($user = '', $pass = '') {
		if (!$user) {
			$user = $this->getUsername();
		}

		if (!$pass) {
			$pass = $this->getPassword();
		}

		$data = '{
			"AuthFlow": "USER_PASSWORD_AUTH",
			"ClientId": "' . self::CLIENT_ID . '",
			"AuthParameters": {
				"USERNAME": "' . addslashes($user) . '",
				"PASSWORD": "' . htmlspecialchars_decode(addslashes($pass)) . '"
			},
			"ClientMetadata": {}
		}';

		$result = $this->curl($data, self::AUTH_URL, [
			'Content-Type: application/x-amz-json-1.1',
			'X-Amz-Target: AWSCognitoIdentityProviderService.InitiateAuth',
		]);

		$this->session->data['rbi_token'] = [
			'IdToken' => '',
			'ExpiresIn' => time(),
		];

		unset($this->session->data['error']);

		if ($result['error']) {
			$this->session->data['error'] = $result['error'];
		} elseif(isset($result['response']['Message'])) {
			$this->session->data['error'] = $result['response']['Message'];
		} elseif(isset($result['response']['message'])) {
			$this->session->data['error'] = $result['response']['message'];
		} elseif (isset($result['response']['AuthenticationResult'])) {
			$this->session->data['rbi_token'] = $result['response']['AuthenticationResult'];
			$this->session->data['rbi_token']['ExpiresIn'] += time();
		}

		return (bool)$this->session->data['rbi_token']['IdToken'];
	}

	public function getBearerToken() {
		$expirationTS = isset($this->session->data['rbi_token']['ExpiresIn']) ? $this->session->data['rbi_token']['ExpiresIn'] : 0;
		$tokenExpired = $expirationTS <= time() ? true : false;

		if ($tokenExpired) {
			$this->retrieveToken();
		}

		return $this->session->data['rbi_token']['IdToken'];
	}

	public function setStoreId($store_id) {
		$this->store_id = $store_id;
	}

	public function curl($data, $url, $headers = []) {
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

		if ($data) {
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			curl_setopt($curl, CURLOPT_POST, true);
			curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
		} else {
			curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
		}

		if ($headers) {
			curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
		}

		$curl_resp = curl_exec($curl);
		$response = json_decode($curl_resp, true);

		$crl['error'] = curl_errno($curl) || curl_error($curl) ? '('.curl_errno($curl).') ' . curl_error($curl) : '';
		$crl['response'] = $response;

		curl_close($curl);

		return $crl;
	}

	public function log($content, $append = false) {
		if ($this->get('debug')) {
			if ($append) {
				file_put_contents(DIR_LOGS. 'rbi.log', "\n\n" . $content, FILE_APPEND);
			} else {
				file_put_contents(DIR_LOGS. 'rbi.log', $content);
			}
		}
	}
}