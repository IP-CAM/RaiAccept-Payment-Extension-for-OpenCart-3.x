<?php
/**
 * Copyright (c) 2023 Raiffeisenbank International
*/

class ControllerExtensionPaymentRbi extends Controller {

	public function __construct($registry) {
		parent::__construct($registry);
		$this->rbi = new Rbi($registry);

		$this->rbi_currency = $this->rbi->get('currency') ? $this->rbi->get('currency') : $this->session->data['currency'];
	}

	public function index() {
		$this->load->model('checkout/order');
		$this->load->model('extension/payment/rbi');

		$this->language->load('extension/payment/rbi');

		$data['button_confirm'] = $this->language->get('button_confirm');
		$data['form_type'] = $this->rbi->get('payment_form');

		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

		if ($order_info) {
			if (empty($this->session->data['rbi_order'][$this->session->data['order_id']])) {
				$orderEntry = $this->createOrderEntry($order_info);
			} else {
				$orderEntry = $this->session->data['rbi_order'][$this->session->data['order_id']];
			}

			$data['action'] = '';
			$data['reload'] = 'true';

			if (isset($orderEntry['orderIdentification'])) {
				if (empty($this->session->data['rbi_order'][$this->session->data['order_id']])) {
					unset($this->session->data['rbi_order']);
					$this->session->data['rbi_order'][$this->session->data['order_id']] = $orderEntry;
				}

				$result = $this->createCheckoutSession($order_info, $orderEntry['orderIdentification']);

				$this->model_extension_payment_rbi->addRbiOrder(
					$this->session->data['order_id'],
					$orderEntry,
					$this->rbi->get('mode'),
					$this->rbi_currency,
					$this->currency->getValue($this->rbi_currency)
				);

				if (isset($result['paymentRedirectURL'])) {
					if ($data['form_type'] == 'iframe') {
						$result['paymentRedirectURL'] .= '&mode=frameless';
					}

					$lang = substr($this->session->data['language'], 0, 2);
					$result['paymentRedirectURL'] .= '&preferredLocale=' . $lang;

					$data['action'] = $result['paymentRedirectURL'];
					$data['reload'] = 'false';
				}
			}

			return $this->load->view('extension/payment/rbi', $data);
		}
	}

	public function getPayload($order) {
		$payment_address = $this->session->data['payment_address'];
		$shipping_address = isset($this->session->data['shipping_address']) ? $this->session->data['shipping_address'] : $payment_address;

		if ($this->customer->isLogged()) {
			$consumer = [
				"email" => $this->customer->getEmail(),
				"firstName" => $this->customer->getFirstName(),
				"lastName" => $this->customer->getLastName(),
				"phone" => $this->customer->getTelephone(),
				"ipAddress" => $this->request->server['REMOTE_ADDR'],
				"mobilePhone" => "",
				"workPhone" => ""
			];
		} else {
			$consumer = [
				"email" => $this->session->data['guest']['email'],
				"firstName" => $this->session->data['guest']['firstname'],
				"lastName" => $this->session->data['guest']['lastname'],
				"phone" => $this->session->data['guest']['telephone'],
				"ipAddress" => $this->request->server['REMOTE_ADDR'],
				"mobilePhone" => "",
				"workPhone" => ""
			];
		}

		$consumer['phone'] = preg_replace('/(?!\+)\D/', '', $consumer['phone']);
		$consumer['phone'] = substr($consumer['phone'], 0, 1) . str_replace('+', '', substr($consumer['phone'], 1, 14));

		$consumer['email'] = substr($consumer['email'], 0, 255);
		$consumer['firstName'] = substr($consumer['firstName'], 0, 32);
		$consumer['lastName'] = substr($consumer['lastName'], 0, 32);

		$items = [];
		$products = $this->cart->getProducts();
		foreach($products as $product) {
			$items[] = [
				"description" => substr($product["name"], 0, 100),
				"numberOfItems" => (int)$product["quantity"],
				"price" => round($this->currency->convert($product["price"], $this->config->get('config_currency'), $this->rbi_currency), 2)
			];
		}

		$sd = '&SD=' . $this->session->getId();
		$iframe = $this->rbi->get('payment_form') == 'iframe' ? '&iframe=true' : '';

		$data = [
			"billingAddress" => [
				"addressStreet1" => substr($payment_address['address_1'], 0, 50),
				"addressStreet2" => substr($payment_address['address_2'], 0, 50),
				"addressStreet3" => "",
				"city" => substr($payment_address['city'], 0, 50),
				"country" => $payment_address['iso_code_3'],
				"firstName" => substr($payment_address['firstname'], 0, 32),
				"lastName" => substr($payment_address['lastname'], 0, 32),
				"postalCode" => substr($payment_address['postcode'], 0, 16),
				"state" => '',
			],
			"consumer" => $consumer,
			"invoice" => [
				"amount" => round($this->currency->convert($order['total'], $this->config->get('config_currency'), $this->rbi_currency), 2),
				"currency" => $this->rbi_currency,
				"description" => $this->rbi->get('description'),
				"items" => $items,
				"merchantOrderReference" => $order['order_id']
			],
			"paymentMethodPreference" => "CARD",
			"shippingAddress" => [
				"addressStreet1" => substr($shipping_address['address_1'], 0, 50),
				"addressStreet2" => substr($shipping_address['address_2'], 0, 50),
				"addressStreet3" => "",
				"city" => substr($shipping_address['city'], 0, 50),
				"country" => $shipping_address['iso_code_3'],
				"firstName" => substr($shipping_address['firstname'], 0, 32),
				"lastName" => substr($shipping_address['lastname'], 0, 32),
				"postalCode" => substr($shipping_address['postcode'], 0, 16),
				"state" => '',
			],
			"isProduction" => (bool)$this->rbi->get('mode') == 'production',
			"urls" => [
				"cancelUrl" => HTTPS_SERVER . "index.php?route=extension/payment/rbi/cancel&orderId={$order['order_id']}$iframe&headless=true$sd",
				"failUrl" => HTTPS_SERVER . "index.php?route=extension/payment/rbi/fail&orderId={$order['order_id']}$iframe&headless=true$sd",
				"successUrl" => HTTPS_SERVER . "index.php?route=extension/payment/rbi/success&orderId={$order['order_id']}$iframe&headless=true$sd",
				"notificationUrl" => HTTPS_SERVER . "index.php?route=extension/payment/rbi/notify&headless=true",
			]
		];

		return $data;
	}

	public function createOrderEntry($order) {
		$data = $this->getPayload($order);
		unset($this->session->data['error']);

		$result = $this->rbi->curl(json_encode($data), Rbi::ORDERS_URL, [
			"Accept: application/json",
			"Content-Type: application/json",
			"Authorization: Bearer " . $this->rbi->getBearerToken()
		]);

		if (isset($result['response']['orderIdentification'])) {
			return $result['response'];
		} elseif (isset($result['response']['message'])) {
			$message = '';
			if (isset($result['response']['errors'][0]['message'])) {
				$message = $result['response']['errors'][0]['message'];
			}

			$field = '';
			if (isset($result['response']['errors'][0]['fieldName'])) {
				$field = $result['response']['errors'][0]['fieldName'];
			}

			if ($field || $message) {
				$result['response']['message'] .= "<br> $field - $message";
			}

			$this->session->data['error'] = $result['response']['message'];
		} else {
			$this->session->data['error'] = $this->language->get('error_order_entry');
		}

		return ['redirect' => $this->url->link('checkout/checkout', '', true)];
	}

	public function createCheckoutSession($order, $orderIdentification) {
		$data = $this->getPayload($order);
		$data['urls']['cancelUrl'] = str_replace("orderId={$order['order_id']}", "orderId={$orderIdentification}", $data['urls']['cancelUrl']);
		$data['urls']['failUrl'] = str_replace("orderId={$order['order_id']}", "orderId={$orderIdentification}", $data['urls']['failUrl']);
		$data['urls']['successUrl'] = str_replace("orderId={$order['order_id']}", "orderId={$orderIdentification}", $data['urls']['successUrl']);

		unset($this->session->data['error']);
		$result = $this->rbi->curl(json_encode($data), Rbi::ORDERS_URL . "/$orderIdentification/checkout" , [
			"Accept: application/json",
			"Content-Type: application/json",
			"Authorization: Bearer " . $this->rbi->getBearerToken()
		]);

		if (isset($result['response']['paymentRedirectURL'])) {
			return $result['response'];
		} elseif (isset($result['response']['message'])) {
			$message = '';
			if (isset($result['response']['errors'][0]['message'])) {
				$message = $result['response']['errors'][0]['message'];
			}

			$field = '';
			if (isset($result['response']['errors'][0]['fieldName'])) {
				$field = $result['response']['errors'][0]['fieldName'];
			}

			if ($field || $message) {
				$result['response']['message'] .= "<br> $field - $message";
			}

			$this->session->data['error'] = $result['response']['message'];
		} elseif (isset($result['error'])) {
			$this->session->data['error'] = $result['error'];
		} else {
			$this->session->data['error'] = $this->language->get('error_checkout_session');
		}
	}

	public function restoreSession($phpsessid, $defaultSessId) {
		session_abort();
		session_id($phpsessid);

		$session = new Session($this->config->get('session_engine'), $this->registry);
		$this->registry->set('session', $session);
		$session->start($defaultSessId);

		setcookie($this->config->get('session_name'), $session->getId(), ini_get('session.cookie_lifetime'), ini_get('session.cookie_path'), ini_get('session.cookie_domain'));
	}

	public function iframe() {
		if ($this->rbi->get('payment_form') == 'iframe' && $_GET['iframe'] == 'true') {
			$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$actual_link = str_replace('iframe=true', 'iframe=false', $actual_link);
			echo "<script>parent.closeIframePopup('$actual_link');</script>";
			die;
		}
	}

	public function success() {
		$this->iframe();

		$this->load->language('extension/payment/rbi');
		$this->load->model('extension/payment/rbi');

		$success = false;
		$response = $this->request->get;

		$text_error = '';

		$orderIdentification = isset($response['orderId']) ? $response['orderId'] : '';
		$rbi_order = $this->model_extension_payment_rbi->getRbiOrder($orderIdentification);
		$order_info = [];

		if ($rbi_order) {
			$this->restoreSession($rbi_order['phpsessid'], $response['SD']);

			$this->load->model('checkout/order');
			$order_info = $this->model_checkout_order->getOrder((int)$rbi_order['order_id']);
		}

		if ($order_info) {
			$success = true;
		} else {
			$text_error = $this->language->get('error_order');
		}

		if ($success) {
			unset($this->session->data['rbi_order']);
			$this->response->redirect($this->url->link('checkout/success'));
		} else {
			$this->document->setTitle($this->language->get('text_title'));

			$data['heading_title'] = $this->language->get('text_failed');
			$data['text_message'] = sprintf($this->language->get('text_failed_message'), $text_error);
			$data['button_continue'] = $this->language->get('button_continue');

			$data['continue'] = $this->url->link('checkout/checkout', '', true);

			$data['breadcrumbs'] = [];

			$data['breadcrumbs'][] = [
				'href'      => $this->url->link('common/home'),
				'text'      => $this->language->get('text_home'),
				'separator' => false
			];

			$data['breadcrumbs'][] = [
				'href'      => $this->url->link('checkout/cart'),
				'text'      => $this->language->get('text_cart'),
				'separator' => $this->language->get('text_separator')
			];

			$data['breadcrumbs'][] = [
				'href'      => $this->url->link('checkout/checkout', '', true),
				'text'      => $this->language->get('text_checkout'),
				'separator' => $this->language->get('text_separator')
			];

			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['content_top'] = $this->load->controller('common/content_top');
			$data['content_bottom'] = $this->load->controller('common/content_bottom');
			$data['footer'] = $this->load->controller('common/footer');
			$data['header'] = $this->load->controller('common/header');

			$this->response->setOutput($this->load->view('common/success', $data));
		}
	}

	public function cancel() {
		$this->iframe();

		$this->load->language('extension/payment/rbi');
		$this->load->model('extension/payment/rbi');

		$response = $this->request->get;

		$orderIdentification = isset($response['orderId']) ? $response['orderId'] : '';
		$rbi_order = $this->model_extension_payment_rbi->getRbiOrder($orderIdentification);
		$order_info = [];

		if ($rbi_order) {
			$this->restoreSession($rbi_order['phpsessid'], $response['SD']);

			$this->load->model('checkout/order');
			$order_info = $this->model_checkout_order->getOrder((int)$rbi_order['order_id']);
		}

		if ($order_info) {
			$this->model_checkout_order->addOrderHistory((int)$rbi_order['order_id'], $this->rbi->get('order_status_canceled_id'));
		} else {
			$this->session->data['error'] = $this->language->get('error_order');
		}

		if (!empty($rbi_order['response']['transaction']['status']) && $rbi_order['response']['transaction']['status'] == 'FAILED') {
			$this->session->data['error'] = $rbi_order['response']['transaction']['statusMessage'];
		}

		header('Location: ' . $this->url->link('checkout/checkout'));
	}

	public function fail() {
		$this->iframe();

		$this->load->language('extension/payment/rbi');
		$this->load->model('extension/payment/rbi');

		$response = $this->request->get;
		$text_error = '';

		$orderIdentification = isset($response['orderId']) ? $response['orderId'] : '';
		$rbi_order = $this->model_extension_payment_rbi->getRbiOrder($orderIdentification);
		$order_info = [];

		if ($rbi_order) {
			$this->restoreSession($rbi_order['phpsessid'], $response['SD']);

			$this->load->model('checkout/order');
			$order_info = $this->model_checkout_order->getOrder((int)$rbi_order['order_id']);
		}

		if (!empty($rbi_order['response']['transaction']['status']) && $rbi_order['response']['transaction']['status'] == 'FAILED') {
			$text_error = $rbi_order['response']['transaction']['statusMessage'];
		}

		if (!$order_info) {
			$text_error = $this->language->get('error_order');
		}

		$this->document->setTitle($this->language->get('text_title'));

		$data['heading_title'] = $this->language->get('text_failed');
		$data['text_message'] = sprintf($this->language->get('text_failed_message'), $text_error);
		$data['button_continue'] = $this->language->get('button_continue');

		$data['continue'] = $this->url->link('checkout/checkout', '', true);

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'href'      => $this->url->link('common/home'),
			'text'      => $this->language->get('text_home'),
			'separator' => false
		];

		$data['breadcrumbs'][] = [
			'href'      => $this->url->link('checkout/cart'),
			'text'      => $this->language->get('text_cart'),
			'separator' => $this->language->get('text_separator')
		];

		$data['breadcrumbs'][] = [
			'href'      => $this->url->link('checkout/checkout', '', true),
			'text'      => $this->language->get('text_checkout'),
			'separator' => $this->language->get('text_separator')
		];

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

		$this->response->setOutput($this->load->view('common/success', $data));
	}

	public function notify() {
		$this->load->language('extension/payment/rbi');
		$this->load->model('extension/payment/rbi');
		$this->load->model('checkout/order');

		$response_raw = file_get_contents('php://input');
		$response = json_decode($response_raw, true);

		$this->rbi->log($response_raw . PHP_EOL);

		if (empty($response['order']['orderIdentification'])) {
			return;
		}

		$rbi_order = $this->model_extension_payment_rbi->getRbiOrder($response['order']['orderIdentification']);

		if (!$rbi_order) {
			$this->rbi->log($this->language->get('error_order') . ' ' . $response['order']['orderIdentification']);
			return;
		}

		$order_status_id = 0;

		if ($response['transaction']['transactionType'] == 'REFUND') {
			if ($response['transaction']['status'] == 'SUCCESS') {
				$order_status_id = $this->rbi->get('order_status_refunded_id');
				$this->model_extension_payment_rbi->updateRefundedAmount((int)$rbi_order['order_id'], $rbi_order['refunded_amount'] + $response['transaction']['transactionAmount']);
			}

			$this->model_extension_payment_rbi->addRbiRefundResponse((int)$rbi_order['order_id'], $response);
		} else {
			if ($response['transaction']['status'] == 'SUCCESS') {
				$order_status_id = $this->rbi->get('order_status_completed_id');
			} elseif ($response['transaction']['status'] == 'FAILED') {
				$order_status_id = $this->rbi->get('order_status_failed_id');
			}

			$this->model_extension_payment_rbi->addRbiResponse((int)$rbi_order['order_id'], $response);
		}

		$this->model_checkout_order->addOrderHistory((int)$rbi_order['order_id'], $order_status_id, $response['transaction']['statusMessage']);
	}
}