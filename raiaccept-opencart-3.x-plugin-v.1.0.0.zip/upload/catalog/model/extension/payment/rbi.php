<?php
/**
 * Copyright (c) 2023 Raiffeisenbank International
*/

class ModelExtensionPaymentRbi extends Model {
	public function __construct($registry) {
		parent::__construct($registry);
		$this->rbi = new Rbi($registry);
	}

	public function getMethod($address, $total) {
		$this->load->language('extension/payment/rbi');

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->rbi->get('geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");

		if ($this->rbi->get('total') > 0 && $this->rbi->get('total') > $total) {
			$status = false;
		} elseif (!$this->rbi->get('geo_zone_id')) {
			$status = true;
		} elseif ($query->num_rows) {
			$status = true;
		} else {
			$status = false;
		}

		$method_data = [];

		if ($status) {
			$method_data = [
				'code'       => 'rbi',
				'title'      => $this->language->get('text_title'),
				'terms'      => '',
				'sort_order' => $this->rbi->get('sort_order')
			];
		}

		return $method_data;
	}

	public function addRbiOrder($order_id, $request, $mode, $currency, $currency_value) {
		$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "rbi_order` SET `order_id` = '" . (int)$order_id . "', `mode` = '" . $this->db->escape($mode) . "', `request` = '" . $this->db->escape(serialize($request)) . "', `orderIdentification` = '" . $this->db->escape($request['orderIdentification']) . "', phpsessid = '" . $this->db->escape(session_id()) . "', `currency` = '" . $this->db->escape($currency) . "', `currency_value` = '" . $this->db->escape($currency_value) . "', `date_added` = NOW()");
	}

	public function addRbiResponse($order_id, $response) {
		$this->db->query("UPDATE `" . DB_PREFIX . "rbi_order` SET `response` = '" . $this->db->escape(serialize($response)) . "' WHERE `order_id` = '" . (int)$order_id . "'");
	}

	public function addRbiRefundResponse($order_id, $response) {
		$this->db->query("UPDATE `" . DB_PREFIX . "rbi_order` SET `refund_response` = '" . $this->db->escape(serialize($response)) . "' WHERE `order_id` = '" . (int)$order_id . "'");
	}

	public function updateRefundedAmount($order_id, $amount): void {
		$this->db->query("UPDATE `" . DB_PREFIX . "rbi_order` SET `refunded_amount` = '" . $this->db->escape($amount) . "' WHERE `order_id` = '" . (int)$order_id . "'");
	}

	public function getRbiOrder($orderIdentification) {
		$result = $this->db->query("SELECT * FROM `" . DB_PREFIX . "rbi_order` WHERE `orderIdentification` = '" . $this->db->escape($orderIdentification) . "' LIMIT 1");

		if (!$result->num_rows) {
			return [];
		}

		$result->row['request'] = unserialize($result->row['request']);
		$result->row['response'] = unserialize($result->row['response']);
		$result->row['refund_response'] = unserialize($result->row['refund_response']);

		return $result->row;
	}
}