<?php
/**
 * Copyright (c) 2023 Raiffeisenbank International
*/

class ControllerExtensionPaymentRbi extends Controller {
	const VERSION = '1.0.0';

	private $error = [];

	public $defaults = [
		'mode' => 'sandbox',
		'status' => '1',
		'sort_order' => '-1',
	];

	public $settingNames = [
		'mode',
		'sandbox_username',
		'sandbox_password',
		'production_username',
		'production_password',
		'payment_form',
		'description',
		'currency',
		'total',
		'order_status_canceled_id',
		'order_status_completed_id',
		'order_status_refunded_id',
		'order_status_failed_id',
		'geo_zone_id',
		'status',
		'debug',
		'sort_order',
	];

	public function __construct($registry) {
		parent::__construct($registry);
		$this->rbi = new Rbi($registry);
	}

	public function index() {
		$this->load->language('extension/payment/rbi');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');
		$this->load->model('extension/payment/rbi');

		if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validate()) {
			$this->model_setting_setting->editSetting(rtrim($this->rbi->prefix, '_'), $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->session->data['error'])) {
			$data['error'] = $this->session->data['error'];
			unset($this->session->data['error']);
		} else {
			$data['error'] = '';
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'][] = [
			'text'	  => $this->language->get('text_home'),
			'href'	  => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], true),
			'separator' => false
		];

		$data['breadcrumbs'][] = [
			'text'	  => $this->language->get('text_payment'),
			'href'	  => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true),
			'separator' => ' :: '
		];

		$data['breadcrumbs'][] = [
			'text'	  => $this->language->get('heading_title'),
			'href'	  => $this->url->link('extension/payment/rbi', 'user_token=' . $this->session->data['user_token'], true),
			'separator' => ' :: '
		];

		$data['action'] = $this->url->link('extension/payment/rbi', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);

		if (isset($this->request->get['support']) && ($this->request->get['support'] == 'extensa')) {
			$data['support'] = true;
		} else {
			$data['support'] = false;
		}

		$errorNames = [
			'description_length',
			'username',
			'password',
			'credentials_production',
			'credentials_sandbox',
		];

		$data['statuses'] = [
			'completed',
			'refunded',
			'canceled',
			'failed',
		];

		$this->load->model('localisation/order_status');
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		if (!$this->rbi->get('order_status_completed_id')) {
			foreach($data['order_statuses'] as $status) {
				$status['name'] = strtolower($status['name']);
				foreach($data['statuses'] as $module_stat) {
					if (strpos($module_stat, $status['name']) !== false) {
						$this->defaults['order_status_' . $module_stat . '_id'] = $status['order_status_id'];
					}
				}
			}
		}

		$this->addErrors($data, $errorNames);
		$this->addSettings($data);

		$this->load->model('localisation/currency');
		$data['currencies'] = $this->model_localisation_currency->getCurrencies();
		array_unshift($data['currencies'], ['code' => 0, 'title' => $this->language->get('text_none')]);

		$data['total_currency'] = '(' . $this->config->get('config_currency') . '):';
		$data['version'] = sprintf($this->language->get('text_plugin_version'), VERSION, self::VERSION);

		$this->load->model('localisation/geo_zone');
		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/rbi', $data));
	}

	private function addErrors(&$data, $errorNames) {
		foreach ($errorNames as $errorName) {
			if (isset($this->error[$errorName])) {
				$data['error_' . $errorName] = $this->error[$errorName];
			} else {
				$data['error_' . $errorName] = '';
			}
		}
	}

	private function addSettings(&$data) {
		foreach ($this->settingNames as $settingName) {
			$oc_settingName = $this->rbi->prefix . $settingName;

			if (isset($this->request->post[$oc_settingName])) {
				$data[$oc_settingName] = $this->request->post[$oc_settingName];
			} else {
				$data[$oc_settingName] = $this->rbi->get($oc_settingName);
			}

			if ($data[$oc_settingName] === null && isset($this->defaults[$settingName])) {
				$data[$oc_settingName] = $this->defaults[$settingName];
			}
		}
	}

	private function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/rbi')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;
		$mode = $post[$this->rbi->prefix . 'mode'];
		if (!$post[$this->rbi->prefix . $mode . '_username']) {
			$this->error['username'] = $this->language->get('error_username');
		}

		if (!$post[$this->rbi->prefix . $mode . '_password']) {
			$this->error['password'] = $this->language->get('error_password');
		}

		if (!$this->error && !$this->rbi->retrieveToken($post[$this->rbi->prefix . $mode . '_username'], $post[$this->rbi->prefix . $mode . '_password'])) {
			$this->error['credentials_' . $mode] = $this->language->get('error_credentials_' . $mode);
		}

		if (strlen(mb_convert_encoding($post[$this->rbi->prefix . 'description'], 'Windows-1251', 'UTF-8')) > 200) {
			$this->error['description_length'] = $this->language->get('error_description_length');
		}

		if ($this->error) {
			$this->error['warning'] = $this->language->get('error_general');
		}

		return !$this->error;
	}

	public function order() {
		$this->language->load('extension/payment/rbi');

		$this->load->model('extension/payment/rbi');

		$data['order_id'] = $this->request->get['order_id'];
		$data['rbi_order'] = $this->model_extension_payment_rbi->getRbiOrder($data['order_id']);

		if (empty($data['rbi_order']) || empty($data['rbi_order']['response'])) {
			return '';
		}

		$data['mode'] = $this->language->get('text_' . $data['rbi_order']['mode']);

		$data['entry_refunded_amount'] = $this->language->get('entry_refunded_amount');
		$data['entry_mode'] = $this->language->get('entry_mode');
		$data['entry_refund'] = $this->language->get('entry_refund');
		$data['entry_tran_statuses'] = $this->language->get('entry_tran_statuses');

		$data['button_refund'] = $this->language->get('button_refund');
		$data['button_refund_full'] = $this->language->get('button_refund_full');
		$data['button_status'] = $this->language->get('button_status');

		$currency = $data['rbi_order']['currency'];
		$refunded_amount = number_format($data['rbi_order']['refunded_amount'], 2, '.', '');
		$paid_amount = number_format($data['rbi_order']['request']['invoice']['amount'], 2, '.', '');

		$data['error_more_than_0'] = $this->language->get('error_more_than_0');
		$data['refunded_amount'] = "$refunded_amount $currency" . $this->language->get('text_out_of') . "$paid_amount $currency";

		$data['user_token'] = $this->request->get['user_token'];
		$data['amount'] = $paid_amount;

		return $this->load->view('extension/payment/rbi_order', $data);
	}

	public function refund() {
		$this->language->load('extension/payment/rbi');

		$this->load->model('extension/payment/rbi');
		$this->load->model('sale/order');

		$rbi_order = $this->model_extension_payment_rbi->getRbiOrder($this->request->get['order_id']);
		$order = $this->model_sale_order->getOrder($this->request->get['order_id']);
		$json = [];

		if ($rbi_order && $order && isset($this->request->post['rbi_amount'])) {
			$rbiAmount = str_replace(',', '.', $this->request->post['rbi_amount']);
			$currencyCode = $rbi_order['currency'];

			if (is_numeric($rbiAmount)) {
				$amount = $rbi_order['request']['invoice']['amount'];

				$left_for_refund = $amount - $rbi_order['refunded_amount'];
				if ($rbiAmount > $left_for_refund) {
					$json['error'] = $this->language->get('error_unavailable_amount');
					$json['error'] = sprintf($json['error'], number_format($left_for_refund, 2, '.', ''), $currencyCode);
				}

				if ($rbiAmount > $amount) {
					$json['error'] = $this->language->get('error_amount_exceeded');
				}

				if ($rbiAmount < 0) {
					$json['error'] = $this->language->get('error_more_than_0');
				}

				if (!isset($json['error'])) {
					$amount = $rbiAmount == '0' ? $amount - $rbi_order['refunded_amount'] : $rbiAmount;

					$data = [
						'amount' => round($amount, 2),
						'currency' => $currencyCode
					];

					$curl = $this->rbi->curl(
						json_encode($data),
						$this->rbi->getRefundUrl($rbi_order),
						[
							"Accept: application/json",
							"Content-Type: application/json",
							"Authorization: Bearer " . $this->rbi->getBearerToken()
						]
					);

					$transactionId = $curl['response']['transactionId'] ?? '';
					if (!$transactionId) {
						$json['error'] = $this->language->get('error_request');
						$json['error'] .= PHP_EOL . $curl['response']['message'];
						$this->response->setOutput(json_encode($json));
						die;
					}

					sleep(1);
					$curl = $this->rbi->curl(
						[],
						$this->rbi->getStatusUrl($rbi_order, $transactionId),
						[
							"Accept: application/json",
							"Authorization: Bearer " . $this->rbi->getBearerToken()
						]
					);

					$response = $curl['response'];

					$this->rbi->log(var_export($response, true), true);

					$update_rbi_order = [];

					if ($response['transaction']['status'] == 'SUCCESS') {
						$refunded_amount = number_format($rbi_order['refunded_amount'] + $amount, 2, '.', '');
						$paid_amount = number_format($rbi_order['request']['invoice']['amount'], 2, '.', '');
						$update_rbi_order['refunded_amount'] = $refunded_amount;
						$amount = number_format($amount, 2, '.', '');

						$json['success'] = sprintf($this->language->get('success_refunded'), $amount, $currencyCode);
						$json['amount'] = "$refunded_amount $currencyCode" . $this->language->get('text_out_of') . "$paid_amount $currencyCode";
						$json['hide_input_fields'] = $refunded_amount >= $rbi_order['request']['invoice']['amount'];
					} else {
						if (isset($this->language->get('text_trans_code')[$response['transaction']['statusCode']])) {
							$text_error = $this->language->get('text_trans_code')[$response['transaction']['statusCode']];
						} else {
							$text_error = '';
						}

						$json['error'] = sprintf($this->language->get('error_action_failed'), $response['transaction']['statusCode']);
						$json['error'] .= PHP_EOL . $text_error;
					}
				}
			} else {
				$json['error'] = $this->language->get('error_invalid_number');
			}
		} else {
			$json['error'] = $this->language->get('error_order_missing');
		}

		$this->response->setOutput(json_encode($json));
	}

	public function status() {
		$this->language->load('extension/payment/rbi');
		$this->load->model('extension/payment/rbi');

		$rbi_order = $this->model_extension_payment_rbi->getRbiOrder($this->request->get['order_id']);
		$response = [];

		if ($rbi_order) {
			$curl = $this->rbi->curl(
				[],
				$this->rbi->getOrderStatusesUrl($rbi_order),
				[
					"Accept: application/json",
					"Authorization: Bearer " . $this->rbi->getBearerToken()
				]
			);

			$response = [];

			$timezone_name = timezone_name_from_abbr("", $this->request->get['timezone_offset'], false);
			date_default_timezone_set($timezone_name);

			$total_refunded = 0;

			foreach($curl['response'] as $transaction) {
				if (isset($this->language->get('text_trans_code')[$transaction['statusCode']])) {
					$status = $this->language->get('text_trans_code')[$transaction['statusCode']];
				} else {
					$status = $transaction['statusMessage'];
				}

				if ($transaction['transactionType'] == 'REFUND' && $transaction['status'] == 'SUCCESS') {
					$total_refunded += $transaction['transactionAmount'];
				}

				$ts = strtotime($transaction['createdOn']);
				$transactionAmount = number_format($transaction['transactionAmount'], 2, '.', '');

				$response[$ts] = [
					'id' => ['entry' => $this->language->get('text_transaction_id'), 'value' => $transaction['transactionId']],
					'type' => ['entry' => $this->language->get('text_transaction_type'), 'value' => $transaction['transactionType']],
					'date' => ['entry' => $this->language->get('text_transaction_date'), 'value' => date('d.m.Y H:i:s', $ts)],
					'amount' => ['entry' => $this->language->get('text_transaction_amount'), 'value' => $transactionAmount . ' ' . $transaction['transactionCurrency']],
					'status' => ['entry' => $this->language->get('text_transaction_status'), 'value' => $transaction['status'] . ': ' . $status],
				];
			}

			$this->model_extension_payment_rbi->editRbiOrder($rbi_order['order_id'], ['refunded_amount' => $total_refunded]);
			ksort($response);
		} else {
			$response['error'] = $this->language->get('error_order_missing');
		}

		$this->response->setOutput(json_encode($response));
	}

	public function uninstall() {
		$this->load->model('extension/payment/rbi');

		$this->model_extension_payment_rbi->deleteTables();
	}

	public function install() {
		$this->load->model('extension/payment/rbi');

		$this->model_extension_payment_rbi->install();

		// For telemetry only
		@mail('raiaccept_support@ri-rpc.sk', 'RBI Payment Module installed', HTTP_CATALOG . ' - ' . $this->config->get('config_name') . "\r\n" . 'version - ' . VERSION . "\r\n" . 'IP - ' . $this->request->server['REMOTE_ADDR'], 'MIME-Version: 1.0' . "\r\n" . 'Content-type: text/plain; charset=UTF-8' . "\r\n" . 'From: ' . $this->config->get('config_owner') . ' <' . $this->config->get('config_email') . '>' . "\r\n");
	}
}
